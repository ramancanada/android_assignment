package com.daniel.h06.timedtaskapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    TextView timerText;
    Button startButton, cancelButton;

    final long startMills = System.currentTimeMillis();
    TimerTask task = new TimerTask() {
        @Override
        public void run() {
            long elapsedMills = System.currentTimeMillis() - startMills;
            updateView(elapsedMills);
        }
    };
    Timer timer = new Timer();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        timerText = (TextView)findViewById(R.id.timerText);
        startButton = (Button)findViewById(R.id.btnStartTimer);
        cancelButton = (Button)findViewById(R.id.btnCancel);

    }



    private void updateView(final long elapsedMills) {
        timerText.post(new Runnable() {
            int elapsedSeconds = (int)elapsedMills/1000;
            @Override
            public void run() {
                timerText.setText("Seconds : " + elapsedSeconds);
            }
        });
    }

    public void onStart(View view) {
        timer.schedule(task, 0, 1000);
    }

    public void onCancel(View view) {
        timer.cancel();
        timerText.setText("Cancelled");
    }

}
