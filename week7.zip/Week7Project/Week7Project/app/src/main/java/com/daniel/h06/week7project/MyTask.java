package com.daniel.h06.week7project;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.Button;
import android.widget.TextView;

/**
 * Created by h06 on 2017-02-23.
 */

public class MyTask extends AsyncTask {
    private Context context;
    private TextView textView;
    private Button button;
    private ProgressDialog progressDialog;

    /**
     * Creates a new asynchronous task. This constructor must be invoked on the UI thread.
     */
    public MyTask(Context context, TextView textView, Button button) {
        this.context = context;
        this.textView = textView;
        this.button = button;
    }

    /**
     * Override this method to perform a computation on a background thread. The
     * specified parameters are the parameters passed to {@link #execute}
     * by the caller of this task.
     * <p>
     * This method can call {@link #publishProgress} to publish updates
     * on the UI thread.
     *
     * @param params The parameters of the task.
     * @return A result, defined by the subclass of this task.
     * @see #onPreExecute()
     * @see #onPostExecute
     * @see #publishProgress
     */
    @Override
    protected Object doInBackground(Object[] params) {

        int i = 0;
        synchronized (this) {
            while (i < 10) {
                try {
                    this.wait(1000);
                    i++;
                    publishProgress(i);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        return "Download Complete";
    }

    /**
     * Runs on the UI thread before {@link #doInBackground}.
     *
     * @see #onPostExecute
     * @see #doInBackground
     */
    @Override
    protected void onPreExecute() {
        //super.onPreExecute();
        this.progressDialog = new ProgressDialog(this.context);
        this.progressDialog.setTitle("Downloading File");
        this.progressDialog.setMax(10);
        this.progressDialog.setProgress(0);
        this.progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        this.progressDialog.show();
        this.button.setEnabled(false);

    }

    /**
     * <p>Runs on the UI thread after {@link #doInBackground}. The
     * specified result is the value returned by {@link #doInBackground}.</p>
     * <p>
     * <p>This method won't be invoked if the task was cancelled.</p>
     *
     * @param o The result of the operation computed by {@link #doInBackground}.
     * @see #onPreExecute
     * @see #doInBackground
     * @see #onCancelled(Object)
     */
    @Override
    protected void onPostExecute(Object o) {
        // super.onPostExecute(o);
        this.progressDialog.setMessage("Downloaded");
        this.textView.setText("Downloaded");
        this.button.setEnabled(true);
        this.progressDialog.hide();
    }

    /**
     * Runs on the UI thread after {@link #publishProgress} is invoked.
     * The specified values are the values passed to {@link #publishProgress}.
     *
     * @param values The values indicating progress.
     * @see #publishProgress
     * @see #doInBackground
     */
    @Override
    protected void onProgressUpdate(Object[] values) {

        // super.onProgressUpdate(values);
        this.progressDialog.setProgress((int)values[0]);
        this.progressDialog.setMessage("Downloading");
        this.textView.setText("Downloading");
    }
}
