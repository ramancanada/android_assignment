package com.daniel.h06.downloadapplication;

import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
    EditText edtText;
    TextView txtContent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }

        edtText = (EditText)findViewById(R.id.edtText);
        txtContent = (TextView)findViewById(R.id.txtContent);
        txtContent.setVisibility(View.GONE);

    }

    public void onDownload(View view) {
        try {
            String message;

            URL url = new URL("http://highendtravelservices.com/Sample.html");
            InputStream in = url.openStream();

            setTextToContextArea(in);
        } catch (IOException ie) {
            ie.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onRead(View view) {
        try {
            String fileName = "test_file.txt";
            // Where to store message
            String message;
            // Where to open the file From
            FileInputStream fileInputStream = openFileInput(fileName);
            // Create InputStream Reader Object
            setTextToContextArea(fileInputStream);
        } catch (FileNotFoundException fe) {
            fe.printStackTrace();
        } catch (IOException ie) {
            ie.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setTextToContextArea(InputStream in) throws IOException {
        String message;InputStreamReader inputStreamReader = new InputStreamReader(in);
        // Create BufferedReader Object
        BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
        // Make a string buffer Object
        StringBuffer stringBuffer = new StringBuffer();

        // while there are still lines in Reader, keep Reading lines
        while ((message = bufferedReader.readLine()) != null) {
            // Add what you read to our message string
            stringBuffer.append(message + "\n");
        }

        // Set our text to the message we are getting
        txtContent.setText(stringBuffer.toString());
        // Show Text View
        txtContent.setVisibility(View.VISIBLE);
    }



    public void onWrite(View view) {
        String message = edtText.getText().toString();
        String fileName = "test_file.txt";

        try {
            // Opening the output file (making it)
            FileOutputStream fileOutputStream = openFileOutput(fileName, MODE_PRIVATE);
            // Write Message to File
            fileOutputStream.write(message.getBytes());
            // Close writing
            fileOutputStream.close();

            // Give notification of text Saved
            Toast.makeText(getApplicationContext(), "Message Saved", Toast.LENGTH_LONG).show();

            // Empty Edit Text
            edtText.setText("");

        } catch (FileNotFoundException fe) {
            fe.printStackTrace();
        } catch (IOException ie) {
            ie.printStackTrace();
        }
    }
}
